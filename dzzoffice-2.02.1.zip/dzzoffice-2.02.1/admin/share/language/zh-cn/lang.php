<?php
$lang = array (
	'appname'=>'分享管理'
);

?>