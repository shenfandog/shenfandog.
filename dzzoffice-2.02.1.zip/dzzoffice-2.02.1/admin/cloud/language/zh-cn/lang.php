<?php
$lang = array ( 
	'appname'=>'云设置和管理', 
);
?>