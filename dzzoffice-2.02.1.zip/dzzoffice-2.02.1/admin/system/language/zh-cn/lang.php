<?php
$lang = array (
	'appname'=>'系统工具',
    'systemupgrade'=>'在线升级',
);
?>